/*
 * Completed by: YOUR NAME GOES HERE
 */
package arrays02;


public class Arrays02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    // ----- Initialize array of specified size.             
    int[] a = COMPLETE-THIS-ON-YOUR-OWN
            
    // ----- Initialize array of specified size.             
    int[] b = COMPLETE-THIS-ON-YOUR-OWN
    
    // ----- Declare and initialize integer variable to store minimum value.
    COMPLETE-THIS-ON-YOUR-OWN
            
    // ----- Declare and initialize integer variable to store maximum value.
    COMPLETE-THIS-ON-YOUR-OWN
            
    // ----- Prompt user for array elements and store in array.
    for(COMPLETE-THIS-ON-YOUR-OWN){
        COMPLETE-THIS-ON-YOUR-OWN
    }
    
    // ----- Parse array for minimum element.
    for(COMPLETE-THIS-ON-YOUR-OWN){
        if(COMPLETE-THIS-ON-YOUR-OWN){
            COMPLETE-THIS-ON-YOUR-OWN
        }
    }
    
    // ------ Print minimum and maximum values in the following form:
    // ------ The minimum value in "array" is: xxxxxx
    COMPLETE-THIS-ON-YOUR-OWN
    COMPLETE-THIS-ON-YOUR-OWN
    
    // ----- Parse array for maximum element.
    for(COMPLETE-THIS-ON-YOUR-OWN){
        if(COMPLETE-THIS-ON-YOUR-OWN){
            COMPLETE-THIS-ON-YOUR-OWN
        }
    }
    
    // ----- Prompt user for array elements to store in the second array.
    for(COMPLETE-THIS-ON-YOUR-OWN){
        COMPLETE-THIS-ON-YOUR-OWN
    }
    
    // ----- Compare arrays to see if they are equal.
    for(COMPLETE-THIS-ON-YOUR-OWN){
        for(COMPLETE-THIS-ON-YOUR-OWN){
            if(COMPLETE-THIS-ON-YOUR-OWN){
               // Break out of nested loops and declare the arrays are unequal. 
            }
        }
        // Declare arrays are equal if loops are equal.
    }
    
    }
    
}
