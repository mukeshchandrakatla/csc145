/*
 * Completed by: YOUR NAME GOES HERE
 */
package arrays01;

/**
 *
 * @author mtrutsch
 */
public class Main {

  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    // ----- Create a one-dimensional array of integers using the initializer list approach.
    int[] array = COMPLETE-THIS-ON-YOUR-OWN
      
    // ----- Sum-up all entries in the array using a for-loop
    int sum = COMPLETE-THIS-ON-YOUR-OWN
      
    // ----- Do not hardcode the array length. Check the array size by intercting with the object (array).
    for(COMPLETE-THIS-ON-YOUR-OWN) {
      COMPLETE-THIS-ON-YOUR-OWN    
    }
    
    // ----- Display the sum in the following format:
    // -----
    // ----- The sum of values in "array" is: xxxxxx
    COMPLETE-THIS-ON-YOUR-OWN
  }
}
