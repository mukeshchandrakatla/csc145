/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrays03;

/**
 *
 * @author jjain
 */
public class Circle {
    // ----- Default Constructor
    public Circle(){
        
    }
    
    public String getShape(){
        return "This is a Circle.";
    }
}
