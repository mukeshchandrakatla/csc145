
package arrays03;

/**
 *
 * @author jjain
 */
public class Arrays03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        
        // ----- Declare and initialize an Object array of length 3. 
        
        
        // ----- Fill the array with 3 Circles using a for-loop.
        
        
        // ----- Use a for-loop to print the displayShape method on each of the objects.
        
        
        // ----- Declare and intialize a second Object array of length 3. 
        
        
        // ----- Fill the array with one Circle, one Square, and one Rectangle
        // ----- using indices of the array.
        
        
        // ----- Use a for-loop to print the displayShape method on each of the objects.
        
    }
    
}
